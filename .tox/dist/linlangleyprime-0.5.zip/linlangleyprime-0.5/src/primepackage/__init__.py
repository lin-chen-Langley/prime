from primepackage.primeio import write_primes, read_primes
from primepackage.primemodule import is_prime, get_n_prime
